package seminar3;

public interface Marker {
}
