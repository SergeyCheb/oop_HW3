package seminar3;

public class Employee1 {
    String name;
}
