package seminar3.parent;

public interface Speakable {
    void speak();
}
