package seminar3.parent;

public interface Diseaseable {
     void getIll();
}
