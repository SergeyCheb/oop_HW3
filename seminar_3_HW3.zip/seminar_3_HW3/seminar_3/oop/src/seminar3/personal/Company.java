package seminar3.personal;

import seminar3.Employee1;

public class Company {
    private Employee1 employee;

    public Company() {
        this.employee = new Employee1();
    }
}
