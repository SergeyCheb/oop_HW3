package seminar3.drugstore.components;

import java.util.Objects;

public abstract class Component {
    private final String name;
    private final String weight;
    private final int power;

    public Component(String name, String weight, int power) {
        this.name = name;
        this.weight = weight;
        this.power = power;
    }

    public String getName() {
        return name;
    }

    public int getPower() {
        return power;
    }

    @Override
    public String toString() {
        return String.format(
                "%s {name: %s, weight: %s, power: %s}", this.getClass().getSimpleName(), name, weight, power
        );
    }

    // ��� ������ ������������� ��� ������ IDE
    // ��� ���������� ������ 1 ��
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Component component = (Component) o;
        return power == component.power && Objects.equals(name, component.name) && Objects.equals(weight, component.weight);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, weight, power);
    }
}
