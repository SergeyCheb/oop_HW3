package seminar3.drugstore.components.child;

import seminar3.drugstore.components.Component;

public class Water extends Component {
    public Water(String name, String weight, int power) {
        super(name, weight, power);
    }
}
