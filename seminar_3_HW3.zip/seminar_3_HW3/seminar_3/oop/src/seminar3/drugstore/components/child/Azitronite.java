package seminar3.drugstore.components.child;

import seminar3.drugstore.components.Component;

public class Azitronite extends Component {
    public Azitronite(String name, String weight, int power) {
        super(name, weight, power);
    }
}
