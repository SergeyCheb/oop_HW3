package seminar3.drugstore.components.child;

import seminar3.drugstore.components.Component;

public class Penicillin extends Component {
    public Penicillin(String name, String weight, int power) {
        super(name, weight, power);
    }
}
