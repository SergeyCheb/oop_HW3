package seminar3.drugstore.drug;

import seminar3.drugstore.IterableDrug;

public class CatDrug extends IterableDrug {

}
