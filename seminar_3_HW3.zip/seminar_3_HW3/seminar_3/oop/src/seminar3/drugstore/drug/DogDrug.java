package seminar3.drugstore.drug;

import seminar3.drugstore.Drug;

public class DogDrug extends Drug {
}
