package seminar3.child;

import seminar3.parent.Animal;
import seminar3.parent.Speakable;

public class Dog extends Animal implements Speakable {

    public Dog(String name, String color) {
        super(name, color);
    }

    @Override
    public void speak() {
        System.out.printf("%s ������: ���!%n", getType());
    }

    @Override
    public void hunt() {
        wakeUp();
        toPlay();
        findFood();
        eat();
        toPlay();
        goToSleep();
    }
}
