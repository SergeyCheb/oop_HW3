package seminar2.parent;

public interface Diseaseable {
     void getIll();
}
