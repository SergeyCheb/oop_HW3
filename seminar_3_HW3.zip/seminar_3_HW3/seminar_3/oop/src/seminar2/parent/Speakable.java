package seminar2.parent;

public interface Speakable {
    void speak();
}
